#pragma once

namespace Shared
{
	enum class TileId
	{
		_Invalid = 0,
		_Begin = 1,

		TileWall = 1,

		_Length
	}; 
}

