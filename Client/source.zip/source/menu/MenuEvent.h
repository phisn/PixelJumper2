#pragma once

#include <SFML/Main.hpp>

namespace Menu
{
	struct Event
	{
		union
		{
		};
	};
}