#pragma once

namespace Game
{
	enum class TileId
	{
		Invalid, // no tile should start with zero

		TileWall,

		_Length
	};
}
