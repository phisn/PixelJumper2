#pragma once

namespace Editor
{
	namespace ModeCache
	{
		struct Input
		{
			enum class Selection
			{
				Default

			} selection;

		};

		// currently doesnt need output
		// & doesnt need element
	}
}