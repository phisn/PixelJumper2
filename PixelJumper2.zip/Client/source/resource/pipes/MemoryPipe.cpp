#include "MemoryPipe.h"



MemoryPipe::MemoryPipe()
{
}


MemoryPipe::~MemoryPipe()
{
}
