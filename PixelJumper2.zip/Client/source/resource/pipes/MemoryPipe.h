#pragma once
class MemoryPipe
{
public:
	MemoryPipe();
	~MemoryPipe();
};

