#pragma once

#define IS_EMPTY(str) str == L""

#define LOGGER_ERROR_TITLE L"Error"
#define LOGGER_INFORMATION_TITLE L"Information"
#define LOGGER_WARNING_TITLE L"Warning"

#define LOGGER_TITLE_BEGIN L"["
#define LOGGER_TITLE_END L"]"
#define LOGGER_MESSAGE_PREFIX L" : "

#define LOGGER_SECTION_FAILED L"Failed"
#define LOGGER_SECTION_SUCCESS L"Success"
#define LOGGER_SECTION_TITLE L"Section"

#define LOGGER_SECTION_SUBMESSAGE_PREFIX_END L"-> "
#define LOGGER_SECTION_SUBMESSAGE_PREFIX_MID L"--"

#define LOGGER_SECTION_SUFFIX L" ... "
