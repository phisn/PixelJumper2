#include "VirtualWorld.h"



VirtualWorld::VirtualWorld()
{
}


VirtualWorld::~VirtualWorld()
{
}
