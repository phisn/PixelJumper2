#pragma once

namespace Game
{
	enum class TileId
	{
		Invalid, // no tile should start with zero

		Wall,

		_Length
	};
}
