#include <Client/source/game/tile/GameWallTile.h>

namespace Game
{
	const sf::Color WallTile::COLOR = sf::Color(170, 170, 170);
}
