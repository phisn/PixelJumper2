#pragma once

#include <Client/source/game/GameState.h>

namespace Game
{
	class DependentTileData
	{
	};
}
