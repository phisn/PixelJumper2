#pragma once

#include <Client/source/game/WorldBase.h>

namespace Game
{
	class HostWorld
		:
		public WorldBase
	{
	public:
		using WorldBase::WorldBase;
	};
}
