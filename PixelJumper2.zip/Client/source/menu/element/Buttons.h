#pragma once

#include <Client/source/menu/element/SimpleButton.h>

namespace Menu
{
	class 
}
