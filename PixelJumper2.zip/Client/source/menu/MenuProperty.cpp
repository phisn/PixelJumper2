#include "MenuProperty.h"

namespace Menu
{
	IndependentPropertyBase::IndependentListenerId IndependentPropertyBase::lastId = 0;
}