#pragma once

namespace Menu
{
	enum class Direction
	{
		Horizontal,
		Vertical
	};
}
